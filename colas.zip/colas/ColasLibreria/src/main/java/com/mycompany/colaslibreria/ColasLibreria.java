/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.colaslibreria;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Deque;
import java.util.PriorityQueue;

public class ColasLibreria {

    public static void main(String[] args) {
        System.out.println("Ejercicio colas con libreria de JAVA\n");
        Colasimple();
        ColasCircular();
        ColasPrioridad();
        ColasDoble();
    }
    static void Colasimple(){
      System.out.println("Ejercicio colas Simple");  
      
        Queue<String> java = new ArrayDeque<>();
        java.offer("ANA");
        java.offer("VIVIANA");
        java.offer("LEINER");
        System.out.println("Java : " + java.poll() + " , " + java.poll()+"\n");  
        
    }
     static void ColasCircular(){
      System.out.println("Ejercicio colas Circular: Reutiliza los espacios del arreglo");  
      
        Queue<String> java = new ArrayDeque<>();
        java.offer("ANA");
        java.offer("VIVIANA");
        java.offer("LEINER");
        System.out.println("SALE : "+ java.poll());
        java.offer("FABIO");
        System.out.println("Java : " + java.poll() + " , " + java.poll()+ " ," + java.poll()+ "\n");  
   
}
 static void ColasPrioridad(){
      System.out.println("Ejercicio colas prioridad: el menor numero de atiende primero ");  
      
        Queue<Integer> java = new PriorityQueue<>();
        java.offer(5);
        java.offer(2);
        java.offer(3);
        
        System.out.println("Java : " + java.poll() + " , " + java.poll()+ " ," + java.poll()+ "\n");  
   


}
 static void ColasDoble(){
      System.out.println("colaDoble(DEQUE): permite usar ambos extremos");  
      
        Deque<String> java = new ArrayDeque<>();
        java.offerLast("ANA");
        java.offerLast("VIVIANA");
        java.offerFirst("LEINER");
       
        System.out.println("Java : sale del inicio" + java.pollFirst() + " ,sale del final " + java.pollLast());  
   
}
}