# Reflexión

**1. ¿Por qué no hace falta `if (actual.siguiente == null)`?**

Porque en una lista circular ningún enlace es null: el siguiente del último es el primero. Entonces `actual = actual.siguiente` siempre sirve, incluso en la última parada. Si recorriera con `while (aux != null)` nunca terminaría, porque nadie apunta a null y daría vueltas para siempre. Por eso se usa `do { ... } while (aux != primero)`.

**2. ¿Qué falla si no actualizo `primero` al eliminar el primer nodo?**

`primero` queda apuntando a un nodo que ya no está en el círculo. Por ejemplo, con A, B, C, D y la actual en A: elimino A y `primero` sigue siendo A. Si después agrego E, se calcula `primero.anterior` (D) y A vuelve a entrar al círculo como si nada. Además `tiempoTotal` y `nombresDesdeActual` comparan contra `primero`, así que el do-while puede no terminar nunca.

**3. Complejidad**

| Operación | Manual | Librería (`LinkedList`) |
|---|---|---|
| `agregar` | O(1) | O(1) |
| `siguiente` / `anterior` | O(1) | O(1) |
| `saltar(n)` | O(n % tamaño) | O(tamaño) |
| `eliminarActual` | O(1) | O(1) |

En la manual `agregar` es O(1) porque el último nodo es `primero.anterior`. En la librería `saltar` usa `Collections.rotate`, que recorre toda la lista.

**4. Circularidad lógica en la librería**

La ventaja es que hay mucho menos código y menos riesgo de errores. `eliminarActual` pasó de unas 15 líneas a 2, y ya viene probado. Lo que se pierde es el control de los nodos y sus enlaces. Además cada `siguiente()` cambia el orden real de la cola, así que no se conserva un primero fijo de la ruta.

**5. Parada prioritaria y paradas pendientes**

Para la prioritaria usaría una `PriorityQueue`, porque siempre entrega primero la de mayor prioridad. Para las pendientes usaría una `Queue` (con `ArrayDeque` o `LinkedList`), porque se atienden en orden de llegada: se agrega al final y se saca del frente.
