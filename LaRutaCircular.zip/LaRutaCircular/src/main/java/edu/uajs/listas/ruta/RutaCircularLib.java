package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

public class RutaCircularLib implements RutaCircular {

    private final LinkedList<Parada> cola = new LinkedList<>();

    @Override
    public void agregar(Parada c) {
        cola.addLast(c);
    }

    @Override
    public Parada actual() {
        return cola.peekFirst();
    }

    @Override
    public Parada siguiente() {
        if (cola.isEmpty()) return null;
        cola.addLast(cola.removeFirst());
        return cola.peekFirst();
    }

    @Override
    public Parada anterior() {
        if (cola.isEmpty()) return null;
        cola.addFirst(cola.removeLast());
        return cola.peekFirst();
    }

    @Override
    public Parada saltar(int n) {
        if (cola.isEmpty()) return null;
        Collections.rotate(cola, -n);
        return cola.peekFirst();
    }

    @Override
    public Parada eliminarActual() {
        if (cola.isEmpty()) return null;
        cola.removeFirst();
        return cola.peekFirst();
    }

    @Override
    public int tamanio() {
        return cola.size();
    }

    @Override
    public int tiempoTotal() {
        int total = 0;
        for (Parada p : cola) {
            total += p.minutos();
        }
        return total;
    }

    @Override
    public List<String> nombresDesdeActual() {
        List<String> nombres = new ArrayList<>();
        ListIterator<Parada> it = cola.listIterator();
        while (it.hasNext()) {
            nombres.add(it.next().nombre());
        }
        return nombres;
    }

    public boolean irA(String nombre) {
        ListIterator<Parada> it = cola.listIterator();
        while (it.hasNext()) {
            int indice = it.nextIndex();
            if (it.next().nombre().equalsIgnoreCase(nombre)) {
                saltar(indice);
                return true;
            }
        }
        return false;
    }

    public void reordenar(long semilla) {
        Collections.shuffle(cola, new Random(semilla));
    }
}
